import datetime

from app.tools.encoding_helper import str2file,file2str
from app.controllers.send_email import send_email
# from app.merging import merging
# from app.coin_mark_analysis import coin_mark_analysis
import os
import io
from app.controllers.save_kraken_orderbooks import save_kraken_orderbooks
from app.controllers.get_orderbook_data import get_kraken_orderbook_responses
from app.config.paths import app_path
from app.controllers.analysis import spread_amount


def lambda_handler(event, context):
    """
    start = datetime.datetime.utcnow()
    file_like_object = io.StringIO()
    refresh_cmc_data = True
    results_of_calculation = save_kraken_orderbooks()
    results_of_calculation.to_csv(file_like_object)
    #print(file_like_object.getvalue())
    base64_encoded_file=file2str(file_like_object.getvalue().encode())
    send_email(filename='spread.csv',file=base64_encoded_file,address='H.Yusuff@Bankhaus-Scheich.de', subject='spreads for today')
    stop = datetime.datetime.utcnow()
    delta = stop - start
    print(f"This took {delta}")
    #print(results_of_calculation)
    """
    save_kraken_orderbooks()


if __name__ == '__main__':
    lambda_handler(None, None)
