import datetime

from app.controllers.get_orderbook_data import get_kraken_orderbook_responses
from app.controllers.format_kraken_response_into_orderbook import format_kraken_response

import os
import io
from app.config.paths import data as path_to_data_folder
from app.tools.encoding_helper import file2str

from app.controllers.s3console import save_report_in_s3


def save_kraken_orderbooks():
    kraken_data = get_kraken_orderbook_responses()
    orderbooks = format_kraken_response(kraken_data)
    timestamp = datetime.datetime.utcnow()
    timestamp_as_string = timestamp.strftime("%Y-%m-%dT%H:%M:%S.%fZ")

    for orderbook in orderbooks:
        file_like_object_bids = io.StringIO()
        file_like_object_asks = io.StringIO()
        #orderbook.asks.to_csv(os.path.join(path, f'{orderbook.instrument}_asks.csv'))
        orderbook.asks.to_csv(file_like_object_bids)
        #orderbook.bids.to_csv(os.path.join(path, f'{orderbook.instrument}_bids.csv'))
        orderbook.bids.to_csv(file_like_object_asks)

        file_path_bid = f"{orderbook.instrument}/{timestamp_as_string}/bids.csv"
        save_report_in_s3(file_like_object_bids, file_path_bid)
        file_path_ask = f"{orderbook.instrument}/{timestamp_as_string}/asks.csv"
        save_report_in_s3(file_like_object_asks, file_path_ask)






if __name__ == "__main__":
    #path = os.path.join(path_to_data_folder, 'orderbooks')
    save_kraken_orderbooks()
