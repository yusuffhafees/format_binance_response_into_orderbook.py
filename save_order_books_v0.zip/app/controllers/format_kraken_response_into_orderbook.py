import decimal
import datetime

from app.models.order_book.order.order import Order
from app.models.order_book.order_book import OrderBook


def format_kraken_response(responses) -> list[OrderBook]:
    my_order_books = []
    for response in responses:
        our_data = response['result']
        kraken_instrument = list(our_data.keys())[0]
        asks = [
            Order(
                instrument=kraken_instrument,
                side="ask",
                quantity=decimal.Decimal(ask[1]),
                price=decimal.Decimal(ask[0]),
                insertion_time=datetime.datetime.fromtimestamp(ask[2])
            ) for ask in response["result"][kraken_instrument]['asks']
        ]
        bids = [
            Order(
                instrument=kraken_instrument,
                side="bid",
                quantity=decimal.Decimal(bid[1]),
                price=decimal.Decimal(bid[0]),
                insertion_time=datetime.datetime.fromtimestamp(bid[2])
            ) for bid in response["result"][kraken_instrument]['bids']
        ]
        my_order_books.append(
            OrderBook(
                instrument=kraken_instrument,
                bids=bids,
                asks=asks
            )
        )
    return my_order_books
