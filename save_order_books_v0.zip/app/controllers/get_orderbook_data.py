import requests
import pandas as pd
from app.config.paths import data as path_to_data_folder
import os
import schedule
import time
#import threading


def get_kraken_orderbook_responses() -> list[dict]:
    #threading.Timer(100.0, get_kraken_orderbook_responses).start()
    df = pd.read_csv(os.path.join(path_to_data_folder, 'xchange_curr_master.csv'))
    df = df[df.xchg_code == 'Kraken']
    base_url = 'https://api.kraken.com/0/public'  # /Depth # ?pair=
    endpoint = '/Depth'

    alL_responses = []

    for x in df['xchg_curr_pair'].unique():
        x = x.replace("/", "")

        path_parameters = {
        "pair": x,
        "count": 500
        }

        response = requests.get(url=base_url + endpoint, params=path_parameters)
        response=response.json() # resturns a dictionary or list
        alL_responses.append(response)
        if response == {'error': ['EQuery:Unknown asset pair']}:
            print(x, response)
        elif response == {'error': ['EQuery:Invalid asset pair']}:
            print(x, response)
        else:
            pass
            print(response)
    return alL_responses

get_kraken_orderbook_responses()


