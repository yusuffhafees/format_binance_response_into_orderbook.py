from app.controllers.analysis import spread_amount


def gradient() -> list[float]:
    spread_df, leg2_quant_df = spread_amount()
    spread_df['difference'] =  spread_df[0].diff()
    leg2_quant_df['difference'] = leg2_quant_df[0].diff()
    slopes= spread_df[0].diff() / leg2_quant_df[0].diff()
    print(slopes.mean())

gradient()
