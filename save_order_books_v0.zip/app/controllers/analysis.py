import pandas as pd

from app.controllers.load_orderbooks import load_orderbooks
from app.models.order_book.pricing import bid_pricing, ask_pricing
import numpy as np
import matplotlib.pyplot as plt
#from app.models.order_book.spreads import bid_spread,ask_spread


number_of_datapoints = 1000


def spread_amount() -> tuple[pd.DataFrame, pd.DataFrame]:
    # orderbook
    x = orderbook.bids
    y = orderbook.asks
    #print(x)
    sum_of_bid_quantity = x['quantity'].sum()
    sum_of_ask_quantity = y['quantity'].sum()
    equilibrum_quantity = min(sum_of_bid_quantity, sum_of_ask_quantity)
    #print(equilibrum_quantity)

    quant = []
    leg2_quant = []
    spr = []

    for quantity_on_price in np.linspace(0, equilibrum_quantity, number_of_datapoints)[1:-1]:
        ask_spread = ask_pricing(quantity_on_price,
                                 order_book=orderbook.asks)  # gives the ask price of the quantity starting from 0.25
        bid_spread = bid_pricing(quantity_on_price,
                                 order_book=orderbook.bids)  # gives the bid price of the quantity starting from 0.25
        our_spread = (ask_spread - bid_spread) / (
                    (ask_spread + bid_spread) / 2)  # gives the spread of the quantity starting from 0.25
        quant.append(quantity_on_price)
        leg2_quant.append(quantity_on_price * ((ask_spread + bid_spread) / 2))
        spr.append(our_spread)
        # print(ask_spread)
        # print(our_spread)
        # print((ask_spread+bid_spread)/2)
        # print(leg2_quant[-1])
        # print(f'our spread and quatity are respectively:\n{our_spread} and {quantity_on_price}')
    #print(quant)
    # print(spr)
    spr = pd.DataFrame(spr)
    quant = pd.DataFrame(quant)
    leg2_quant = pd.DataFrame(leg2_quant)

    # plt.figure(figsize=(20, 6))
    # plt.plot(leg2_quant.values, spr.values)
    # plt.ylabel('spread')
    # plt.xlabel('quantity')
    #
    # plt.show()
    return spr, leg2_quant



orderbook = load_orderbooks('XXBTZEUR')[0]
#print(spread_amount())
#if __name__ == "__main__":
