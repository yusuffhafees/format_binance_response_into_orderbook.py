import os.path

from app.config.paths import data as path_to_data
import pandas as pd
from app.models.order_book.order_book import OrderBook


def load_orderbooks(instrument=None) -> list[OrderBook]:
    orderbooks = []
    if instrument is None:
        pass
        # we load all orderbooks
    else:
        asks = pd.read_csv(os.path.join(path_to_data, 'orderbooks', f'{instrument}_asks.csv')).drop(columns='Unnamed: 0')
        bids = pd.read_csv(os.path.join(path_to_data, 'orderbooks', f'{instrument}_bids.csv')).drop(columns='Unnamed: 0')
        orderbook = OrderBook(instrument=instrument, bids=[], asks=[])
        orderbook._bids = bids
        orderbook._asks = asks

        orderbooks.append(orderbook)

        # we load a specfic orderbook

    return orderbooks
