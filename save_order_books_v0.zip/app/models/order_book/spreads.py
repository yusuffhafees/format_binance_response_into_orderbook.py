from app.models.order_book.pricing import bid_pricing
from app.models.order_book.pricing import ask_pricing
from app.controllers.load_orderbooks import load_orderbooks
from app.models.exceptions.max_price_exceeded import MaxPriceExceeded


def spread(ask_spread, bid_spread):
    spread_amount = (ask_spread - bid_spread) / ((ask_spread + bid_spread) / 2)
    print("amount of spread is:", end=' ')
    print(spread_amount)
    print("ask_spread:", end=' ')
    print(ask_spread)
    print("bid_spread:", end=' ')
    print(bid_spread)
    print(my_order_books[0].asks)
    print(my_order_books[0].bids)


if __name__ == "__main__":
    my_order_books = load_orderbooks('ALICEEUR')

    to_be_bought = 1000
    to_be_sold = 1000

    try:
        ask_spread = ask_pricing(to_be_bought, order_book=my_order_books[0].asks)
    except MaxPriceExceeded as e:
        print(f"Tried buying {to_be_bought}, only got: {e.bought_quantity}, for {e.price_executed}")
        ask_spread = None

    try:
        bid_spread = bid_pricing(to_be_sold, order_book=my_order_books[0].bids)
    except MaxPriceExceeded as e:
        print(f"Tried buying {to_be_sold}, only got: {e.sold_quantity}, for {e.price_executed}")
        ask_spread = None

    #bid_spread = bid_pricing(quantity=20000, order_book=my_order_books[0].bids)

    if ask_spread is None or bid_spread is None:
        print("Couldnt calculate")
    else:
        print(spread(ask_spread, bid_spread))
