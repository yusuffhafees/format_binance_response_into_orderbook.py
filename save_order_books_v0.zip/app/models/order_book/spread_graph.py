# from app.models.order_book.order.trial import my_order_books
# X=my_order_books[0].bids
# print(my_order_books[0].asks)
# print(X)
import pandas as pd

from app.models.order_book.order.trial import generate_orderbook_list


if __name__ == "__main__":

    orderbooks = generate_orderbook_list()
    orderbooks[0].asks.to_csv('./asks.csv')
    orderbooks[0].bids.to_csv('./bids.csv')

    my_read = pd.read_csv('./asks.csv')



