import pandas as pd
from app.controllers.load_orderbooks import load_orderbooks
from app.models.exceptions.max_price_exceeded import MaxPriceExceeded

# def bid_pricing(x):
#     for stuff in my_order_books[-1]:
#         price_of_instrument= my_order_books[-1]['quantity']/my_order_books[-1]['price']
#         print(price_of_instrument*x)
#
# bid_pricing(1)


def bid_pricing(quantity, order_book):
    leftover_quantity = float(quantity)
    total_price = 0
    i = 0

    max_iterations = len(order_book)
    while leftover_quantity > 0:
        if leftover_quantity <= float(order_book.iloc[i]['quantity']):
            total_price += leftover_quantity * float(order_book.iloc[i]['price'])
            break
        else:
            leftover_quantity -= float(order_book.iloc[i]['quantity'])
            total_price += (float(order_book.iloc[i]['quantity']) * float(order_book.iloc[i]['price']))
            i += 1
            if i == max_iterations:
                sold_quantity = quantity-leftover_quantity
                raise MaxPriceExceeded(leftover_quantity, sold_quantity, total_price)

    # print(f"Bid: {price} for {quantity}")
    return total_price/quantity


# print('Bid price:')
# print(bid_pricing(1000, order_book=my_order_books[0].bids))


def ask_pricing(quantity: int,
                order_book: pd.DataFrame) -> float:
    """
    Function takes in one side of the orderbook, and a customer requested quantity.
    Calculates the price if we try to buy this quantity from the side of the orderbook

    :param quantity:
    :param order_book:
    :return: total_price
    """

    leftover_quantity = float(quantity)
    total_price = 0
    i = 0

    max_iterations = len(order_book)

    while leftover_quantity > 0:
        if leftover_quantity <= float(order_book.iloc[i]['quantity']):
            total_price += leftover_quantity * float(order_book.iloc[i]['price'])
            break
        else:
            leftover_quantity -= float(order_book.iloc[i]['quantity'])
            total_price += (float(order_book.iloc[i]['quantity']) * float(order_book.iloc[i]['price']))
            i += 1
            if i == max_iterations:
                bought_quantity = quantity-leftover_quantity
                raise MaxPriceExceeded(leftover_quantity, bought_quantity, total_price)

    # print(f"Ask: {price} for {quantity}")
    return total_price/quantity


if __name__ == "__main__":
    my_order_books = load_orderbooks('ALICEEUR')
    #print('Ask price:')
    to_be_bought = 1000
    #print('Bid price:')
    to_be_sold = 1000
    try:
        print('Ask price:')
        print(ask_pricing(to_be_bought, order_book=my_order_books[0].asks))
    except MaxPriceExceeded as e:
        print(f"Tried buying {to_be_bought}, only got: {e.bought_quantity}, for {e.price_executed}")
    try:
        print('Bid price:')
        print(bid_pricing(to_be_sold, order_book=my_order_books[0].bids))
    except MaxPriceExceeded as e:
        print(f"Tried selling {to_be_sold}, only got: {e.sold_quantity}, for {e.price_executed}")
