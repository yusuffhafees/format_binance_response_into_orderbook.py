import os


app_path = os.path.join(os.path.dirname(__file__), '..')
data = os.path.join(app_path, 'data')
