BUCKET_NAME = "data-collection-bucket"

STANDARD_PATH = "liquidity_data_collection"

